@extends('layouts.auth')

@section('page.title', 'Страница входа')

@section('auth.content')
    <x-login.card />
@endsection
