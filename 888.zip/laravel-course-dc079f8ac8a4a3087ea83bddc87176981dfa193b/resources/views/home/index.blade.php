@extends('layouts.main')

@section('main.content')
    <div class="text-center">
        <h1>
            Главная страница
        </h1>
    </div>
@endsection
