<footer class="py-3 border-top text-center">
    © {{ config('app.name') }} {{ $date }}
</footer>
