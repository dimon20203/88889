<div class="card mb-3">
    {{ $slot }}
</div>
