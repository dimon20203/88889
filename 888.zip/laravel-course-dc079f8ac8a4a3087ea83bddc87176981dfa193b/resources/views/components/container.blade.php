<div class="container">
    {{ $slot }}
</div>
