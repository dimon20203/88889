<input {{ $attributes->class([
    'form-control',
])->merge([
    'type' => 'text',
]) }}>
