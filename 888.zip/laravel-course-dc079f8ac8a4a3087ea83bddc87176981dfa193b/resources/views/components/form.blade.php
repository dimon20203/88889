<form {{ $attributes }}>
    @csrf {{ $slot }}
</form>
