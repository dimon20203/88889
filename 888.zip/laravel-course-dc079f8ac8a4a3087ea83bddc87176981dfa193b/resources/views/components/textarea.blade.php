<textarea {{ $attributes->class([
    'form-control',
]) }}></textarea>
