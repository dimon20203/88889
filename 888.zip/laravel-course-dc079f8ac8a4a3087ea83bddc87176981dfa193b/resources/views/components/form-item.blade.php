<div class="mb-3">
    {{ $slot }}
</div>
