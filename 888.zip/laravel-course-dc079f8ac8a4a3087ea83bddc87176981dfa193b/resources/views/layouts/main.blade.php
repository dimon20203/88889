@extends('layouts.base')

@section('content')
    <section>
        <x-container>
            @yield('main.content')
        </x-container>
    </section>
@endsection
