<?php

return [
    'foo' => env('EXAMPLE_FOO'),
];
